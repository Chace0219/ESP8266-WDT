Client
======

.. automodule:: paramiko.client
    :member-order: bysource
